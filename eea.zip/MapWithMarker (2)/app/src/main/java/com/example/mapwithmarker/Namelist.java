package com.example.mapwithmarker;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.prefs.Preferences;


public class Namelist extends AppCompatActivity {
    String data3;
    TextView tv2;
    String[] dataSplit = null;
    String[] dataSplit2 = null;
    String data4;
    String parse;
    String key = "1122334455";
    String whereSearch = null;
    String data;
    String p;
    ListView listview;
    private ListView name1;
    ArrayAdapter<String> adapter;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        Intent intent = getIntent();
        setContentView(R.layout.buslist);
        getSupportActionBar().setTitle("상행                              하행");
        name1 = (ListView) findViewById(R.id.name1);
        data3 = intent.getStringExtra("aaas");
        data4 = intent.getStringExtra("aas");
        System.out.println("테스트" + data4);
        super.onCreate(savedInstanceState);
        data3.replace(" ", "");
        dataSplit = data3.split(","); // 0번 = 버스 고유번호 , 1번 = 버스번호
        for (int i = 0; i < dataSplit.length; i++) {
            if (dataSplit[i].equals(data4)) {
                System.out.println("일치!");
                parse = dataSplit[i - 1];
            }

        }
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    p = getXmlData1(parse);

                } catch (Exception e2){
                    e2.printStackTrace();
                }finally {

                }

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        dataSplit2 = p.split("@"); // 노선목록
                        List<String> list = new ArrayList<>();
                        for(int i = 0; i < dataSplit2.length; i++) {
                            System.out.println(dataSplit2[i]);
                            list.add(dataSplit2[i]);
                            ArrayAdapter<String> adpater = new ArrayAdapter<String>(Namelist.this, android.R.layout.simple_list_item_1, list);
                            name1.setAdapter(adpater);
                           // tv2.setText("테스트1");
                        }


                    }

                });
            }
        }).start();



        //System.out.println("잘나옴?"+p);
    }

    String getXmlData1(String data) throws UnsupportedEncodingException {
        StringBuffer buffer = new StringBuffer();
        //urlBuilder.append("?" + URLEncoder.encode("serviceKey","UTF-8") + "= 1122334455");

        parse = this.parse;

        whereSearch = "http://openapi.gbis.go.kr/ws/rest/busrouteservice/station?serviceKey="+key+"&routeId="+parse;


        try {
            URL url = new URL(whereSearch);
            InputStream is = url.openStream();

            XmlPullParserFactory factory = XmlPullParserFactory.newInstance();//xml파싱을 위한
            XmlPullParser xpp = factory.newPullParser();
            xpp.setInput(new InputStreamReader(is, "UTF-8")); //inputstream 으로부터 xml 입력받기

            String tag;
            int[] i = new int[50];
            int j = 0;
            int tes;
            xpp.next();
            int eventType = xpp.getEventType();
            while (eventType != XmlPullParser.END_DOCUMENT) {
                switch (eventType) {
                    case XmlPullParser.START_DOCUMENT:
                        buffer.append("파싱 시작...\n\n");
                        break;

                    case XmlPullParser.START_TAG:
                        tag = xpp.getName();//테그 이름 얻어오기

                        if (tag.equals("item")) ;// 첫번째 검색결과
//predictTime1  routeName
                        else if (tag.equals("stationName")) {
                            xpp.next();
                            buffer.append(xpp.getText());//map 요소의 TEXT 읽어와서 문자열버퍼에 추가
                            buffer.append("@"); //줄바꿈 문자 추가
                        } /*else if (tag.equals("routeId")) {
                            xpp.next();
                            buffer.append(xpp.getText());//map 요소의 TEXT 읽어와서 문자열버퍼에 추가
                            buffer.append(","); //줄바꿈 문자 추가*/

                        break;

                    case XmlPullParser.TEXT:
                        break;

                    case XmlPullParser.END_TAG:
                        tag = xpp.getName(); //테그 이름 얻어오기

                        if (tag.equals("item")) buffer.append("\n");// 첫번째 검색결과종료..줄바꿈
                        break;
                }

                eventType = xpp.next();
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        buffer.append("\n");
        return buffer.toString();//StringBuffer 문자열 객체 반환
    }
}

       /* Intent intent = getIntent();
        //tv1 =(TextView)findViewById(R.id.tv1);
        list1 = (ListView) findViewById(R.id.list1);
        list2 = (ListView) findViewById(R.id.list2);
        //tv1.setText(data);
        data =  intent.getStringExtra("aaa");
        data2 =  intent.getStringExtra("aaa");
        Log.d("dataFind", data);

        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    p = getXmlData1(data);
                    w = getXmlData2(data2);

                } catch (Exception e2){
                    e2.printStackTrace();
                }finally {

                }

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        dataSplit = p.split(","); // 0번 = 루트번호 , 1번 = 버스번호
                        dataSplit2 = w.split(","); // 0번 = 도착시간 , 1번 = 루트번호

                        //whereRoute = null;
                        for(int p0=0; p0<dataSplit.length; p0++){
                            String asb = dataSplit[p0];
                            if(p0 % 2 == 0){
                                dataSplit1_1.add(asb); //routeId
                            }
                            else{
                                dataSplit1_2.add(asb); // busName
                            }
                        }
                        for(int p0 = 0; p0<dataSplit2.length; p0++){
                            String asb = dataSplit2[p0];
                            if(p0 % 2 == 0){
                                dataSplit2_1.add(asb); // Practi
                            }
                            else{
                                dataSplit2_2.add(asb); // routeId
                            }
                        }



                        for(int index1=0;index1<dataSplit1_1.size(); index1++){
                            for(int index2 =0; index2<dataSplit2_2.size(); index2++) {
                                if (dataSplit1_1.get(index1).equals(dataSplit2_2.get(index2))) {
                                    pracTimeSplit.add(dataSplit2_1.get(index1));
                                }
                            }
                        }

//                        for(int ss = 0; ss<whereRoute.size(); ss++){
//                            System.out.println(whereRoute.get(ss));
//                        }


                        adapter=new ArrayAdapter<String>(busListA.this, android.R.layout.simple_list_item_1, dataSplit1_2);
                        list1.setAdapter(adapter);
                        adapter.notifyDataSetChanged();
                        //tv1.setText(p);

                        adapter=new ArrayAdapter<String>(busListA.this, android.R.layout.simple_list_item_1, pracTimeSplit);
                        list2.setAdapter(adapter);
                        adapter.notifyDataSetChanged();
                        System.out.println("killlllllllllll"+data2);
                        listview= (ListView)findViewById(R.id.list1);
                        listview.setOnItemClickListener(listener);
                    }

                });
            }
        }).start();



    }
    AdapterView.OnItemClickListener listener= new AdapterView.OnItemClickListener() {


        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

            Toast.makeText(busListA.this, "ddd", Toast.LENGTH_SHORT).show();
            Intent intent2 = new Intent(view.getContext() , Namelist.class);
            intent2.putExtra("aaa", data);
            startActivity(intent2);

        }
    };
    String getXmlData1(String data) throws UnsupportedEncodingException {
        StringBuffer buffer = new StringBuffer();
        //urlBuilder.append("?" + URLEncoder.encode("serviceKey","UTF-8") + "= 1122334455");

        data = this.data;

        whereSearch = "http://openapi.gbis.go.kr/ws/rest/busstationservice/route?serviceKey="+key+"&stationId="+data;
        pracSearch = "http://openapi.gbis.go.kr/ws/rest/busarrivalservice/station?serviceKey="+key+"&stationId="+data;


        try{
            URL url = new URL(whereSearch);
            InputStream is = url.openStream();

            XmlPullParserFactory factory= XmlPullParserFactory.newInstance();//xml파싱을 위한
            XmlPullParser xpp= factory.newPullParser();
            xpp.setInput( new InputStreamReader(is, "UTF-8") ); //inputstream 으로부터 xml 입력받기

            String tag;
            int[] i = new int[50] ;
            int j = 0;
            int tes;
            xpp.next();
            int eventType= xpp.getEventType();
            while( eventType != XmlPullParser.END_DOCUMENT ){
                switch( eventType ){
                    case XmlPullParser.START_DOCUMENT:
                        buffer.append("파싱 시작...\n\n");
                        break;

                    case XmlPullParser.START_TAG:
                        tag= xpp.getName();//테그 이름 얻어오기

                        if(tag.equals("item")) ;// 첫번째 검색결과
//predictTime1  routeName
                        else if(tag.equals("routeName")){
                            xpp.next();
                            buffer.append(xpp.getText());//map 요소의 TEXT 읽어와서 문자열버퍼에 추가
                            buffer.append(","); //줄바꿈 문자 추가
                        }

                        else if(tag.equals("routeId")) {
                            xpp.next();
                            buffer.append(xpp.getText());//map 요소의 TEXT 읽어와서 문자열버퍼에 추가
                            buffer.append(","); //줄바꿈 문자 추가
                        }
                        break;

                    case XmlPullParser.TEXT:
                        break;

                    case XmlPullParser.END_TAG:
                        tag= xpp.getName(); //테그 이름 얻어오기

                        if(tag.equals("item")) buffer.append("\n");// 첫번째 검색결과종료..줄바꿈
                        break;
                }

                eventType= xpp.next();
            }

        } catch (Exception e){
            e.printStackTrace();
        }

        buffer.append("\n");
        return buffer.toString();//StringBuffer 문자열 객체 반환
    }

    String getXmlData2(String data2) throws UnsupportedEncodingException {
        StringBuffer buffer = new StringBuffer();
        //urlBuilder.append("?" + URLEncoder.encode("serviceKey","UTF-8") + "= 1122334455");

        data2 = this.data2;

        whereSearch = "http://openapi.gbis.go.kr/ws/rest/busstationservice/route?serviceKey="+key+"&stationId="+data2;
        pracSearch = "http://openapi.gbis.go.kr/ws/rest/busarrivalservice/station?serviceKey="+key+"&stationId="+data2;


        try{
            URL url = new URL(pracSearch);
            InputStream is = url.openStream();

            XmlPullParserFactory factory= XmlPullParserFactory.newInstance();//xml파싱을 위한
            XmlPullParser xpp= factory.newPullParser();
            xpp.setInput( new InputStreamReader(is, "UTF-8") ); //inputstream 으로부터 xml 입력받기

            String tag;
            int[] i = new int[50] ;
            int j = 0;
            int tes;
            xpp.next();
            int eventType= xpp.getEventType();
            while( eventType != XmlPullParser.END_DOCUMENT ){
                switch( eventType ){
                    case XmlPullParser.START_DOCUMENT:
                        buffer.append("파싱 시작...\n\n");
                        break;

                    case XmlPullParser.START_TAG:
                        tag= xpp.getName();//테그 이름 얻어오기

                        if(tag.equals("item")) ;// 첫번째 검색결과

                        else if(tag.equals("predictTime1")){
                            xpp.next();
                            buffer.append(xpp.getText());//map 요소의 TEXT 읽어와서 문자열버퍼에 추가
                            buffer.append(","); //줄바꿈 문자 추가
                        }
                        else if(tag.equals("routeId")) {
                            xpp.next();
                            buffer.append(xpp.getText());//map 요소의 TEXT 읽어와서 문자열버퍼에 추가
                            buffer.append(","); //줄바꿈 문자 추가
                        }

                        break;

                    case XmlPullParser.TEXT:
                        break;

                    case XmlPullParser.END_TAG:
                        tag= xpp.getName(); //테그 이름 얻어오기

                        if(tag.equals("item")) buffer.append("\n");// 첫번째 검색결과종료..줄바꿈
                        break;
                }

                eventType= xpp.next();
            }

        } catch (Exception e){
            e.printStackTrace();
        }

        buffer.append("\n");
        return buffer.toString();//StringBuffer 문자열 객체 반환
    }

        */
