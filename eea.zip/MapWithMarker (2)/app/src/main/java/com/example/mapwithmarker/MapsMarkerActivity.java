// Copyright 2020 Google LLC
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package com.example.mapwithmarker;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.URL;

/**
 * An activity that displays a Google map with a marker (pin) to indicate a particular location.
 */
// [START maps_marker_on_map_ready]
public class MapsMarkerActivity extends AppCompatActivity
        implements OnMapReadyCallback, GoogleMap.OnMarkerClickListener {
    TextView txtResult;

    Marker markers = null;

    //버튼
   /* public void mOnPopupClick(View v){
        //데이터 담아서 팝업(액티비티) 호출
        Intent intent = new Intent(this, PopupActivity.class);
        intent.putExtra("data", "Test Popup");
        startActivityForResult(intent, 1);
    }*/
/*
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1) {
            if (resultCode == RESULT_OK) {
                //데이터 받기
                String result = data.getStringExtra("result");
                txtResult.setText(result);
            }}}*/
    public void mOnClick(View v) {


        switch (v.getId()) {
            case R.id.button:
                mMap.clear();
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            data = getXmlData();

                        } catch (UnsupportedEncodingException e) {
                            e.printStackTrace();
                        }catch (Exception e2){
                            e2.printStackTrace();
                        }

                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                //text.setText(data);
                               // Log.d("text",data);
                               dataSplit = data.split(",");
                                System.out.println(dataSplit.length);
                                double x=0.0;

                                double y=0.0;

                                String s_id;
                                String str = new String();

                                for(int i = 0; i < ((dataSplit.length-1)/4); i++) {
                                   // text.setText(dataSplit[i]);
                                    //Log.d("cats","좌표"+dataSplit[i])

                                    y = Double.valueOf(dataSplit[(i*4)+3]);
                                    x = Double.valueOf(dataSplit[(i*4)+2]);
                                    str = dataSplit[(i*4)+1];
                                    s_id = dataSplit[(i*4)];
                                    Log.d("pppp", "y : " + y);
                                    Log.d("pppp", "x :  "+ x);
                                    Log.d("pppp", "str :  "+ str);
                                    LatLng as = new LatLng(y, x);
                                    MarkerOptions markerOptions = new MarkerOptions();
                                    markerOptions.position(as);
                                    markerOptions.title(str);
                                    markerOptions.snippet(s_id);


                                     markers =  mMap.addMarker(markerOptions);
                                    mMap.moveCamera(CameraUpdateFactory.zoomTo(15));
                                    mMap.moveCamera(CameraUpdateFactory.newLatLng(as));
                                    //t++;
                                }
                                /*
                                for(int i = 0; i < dataSplit.length-1; i++) {
                                    text.setText(dataSplit[i]);
                                    Log.d("cats","좌표"+dataSplit[i]);

                                    if((i%2) ==0)
                                    {
                                        y =Double.valueOf(dataSplit[i]);
                                        Log.d("pppp", "y : " + y);
                                    }
                                    else if ((i%2) ==1)
                                    {
                                        x =Double.valueOf(dataSplit[i]);

                                        Log.d("pppp", "x :  "+x);
                                        xtest[i] = x;
                                        ytest[i] = y;

                                        Log.d("pppp", "x clear"+ ytest[i]);
                                        LatLng as = new LatLng(xtest[i], ytest[i]);
                                        MarkerOptions markerOptions = new MarkerOptions();
                                        markerOptions.position(as);
                                        markerOptions.title("최고");

                                        mMap.addMarker(markerOptions);

                                        mMap.moveCamera(CameraUpdateFactory.zoomTo(15));
                                        mMap.moveCamera(CameraUpdateFactory.newLatLng(as));
                                    }
                                    else if((i%3) == 0)
                                    {
                                        name = dataSplit[i];

                                        System.out.println(name);
                                    }

                                    Log.d("ice" , "i = " + i);

                                }
                                */



                            }
                        });
                    }
                }).start();
                break;
        }



    }
    @Override
    public boolean onMarkerClick(Marker maker)
    {
      //  Intent intent = new Intent(this, PopupActivity.class);
       // intent.putExtra("data", maker.getTitle() +"\n"+ maker.getSnippet());
       // startActivityForResult(intent, 1);
        //Toast.makeText(this, maker.getTitle() + "\n" + "blur", Toast.LENGTH_SHORT).show();
        Intent intent1 = new Intent(this, busListA.class);
        intent1.putExtra("aaa",maker.getSnippet());
        startActivity(intent1);

        return  false;
    }

    private GoogleMap mMap;
    EditText edit_x , edit_y;
    TextView text;
    XmlPullParser xpp;

    String whereSearch;
    String x_head,y_head;

    String key = "1122334455";
    String data = null;
    String[] dataSplit = null;
    //GoogleMap gMap1 = new GoogleMap();

    // [START_EXCLUDE]
    // [START maps_marker_get_map_async]
    @Override
    protected void onCreate(Bundle savedInstanceState ) {
       // setContentView(R.layout.activity_main);

        //txtResult = (TextView)findViewById(R.id.txtResult);
        super.onCreate(savedInstanceState);
        // Retrieve the content view that renders the map.
        setContentView(R.layout.activity_maps);

        edit_x = (EditText) findViewById(R.id.edit_x);
        edit_y = (EditText) findViewById(R.id.edit_y);

        Log.d("test", "테스트");
        text = (TextView) findViewById(R.id.result);
        // Get the SupportMapFragment and request notification
        // when the map is ready to be used.
       SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
              .findFragmentById(R.id.map);
      mapFragment.getMapAsync(this);
    }



    String getXmlData() throws UnsupportedEncodingException {
        StringBuffer buffer = new StringBuffer();
        String str_x = edit_x.getText().toString();//EditText에 작성된 Text얻어오기
        String str_y = edit_y.getText().toString();
        //urlBuilder.append("?" + URLEncoder.encode("serviceKey","UTF-8") + "= 1122334455");



        whereSearch = "http://openapi.gbis.go.kr/ws/rest/busstationservice?serviceKey="+key+"&keyword="+str_x;


        try{
            URL url = new URL(whereSearch);
            InputStream is = url.openStream();

            XmlPullParserFactory factory= XmlPullParserFactory.newInstance();//xml파싱을 위한
            XmlPullParser xpp= factory.newPullParser();
            xpp.setInput( new InputStreamReader(is, "UTF-8") ); //inputstream 으로부터 xml 입력받기

            String tag;
            int[] i = new int[50] ;
            int j = 0;
            int tes;
            xpp.next();
            int eventType= xpp.getEventType();
            while( eventType != XmlPullParser.END_DOCUMENT ){
                switch( eventType ){
                    case XmlPullParser.START_DOCUMENT:
                        buffer.append("파싱 시작...\n\n");
                        break;

                    case XmlPullParser.START_TAG:
                        tag= xpp.getName();//테그 이름 얻어오기

                        if(tag.equals("item")) ;// 첫번째 검색결과
                        else if(tag.equals("x")){
                          //  buffer.append("x : ");
                            xpp.next();
                            buffer.append(xpp.getText());//map 요소의 TEXT 읽어와서 문자열버퍼에 추가
                            buffer.append(","); //줄바꿈 문자 추가
                        }
                        else if(tag.equals("y")){
                           // buffer.append("y : ");
                            xpp.next();
                            buffer.append(xpp.getText());//map 요소의 TEXT 읽어와서 문자열버퍼에 추가
                            buffer.append(","); //줄바꿈 문자 추가
                        }
                        else if(tag.equals("stationName")){
                            //buffer.append("[");
                            xpp.next();
                            buffer.append(xpp.getText());//map 요소의 TEXT 읽어와서 문자열버퍼에 추가
                            buffer.append(","); //줄바꿈 문자 추가
                        }
                        else if(tag.equals("stationId")){
                            xpp.next();
                            buffer.append(xpp.getText());
                            buffer.append(",");
                        }
                        break;

                    case XmlPullParser.TEXT:
                        break;

                    case XmlPullParser.END_TAG:
                        tag= xpp.getName(); //테그 이름 얻어오기

                        if(tag.equals("item")) buffer.append("\n");// 첫번째 검색결과종료..줄바꿈
                        break;
                }

                eventType= xpp.next();
            }

        } catch (Exception e){
            e.printStackTrace();
        }

        buffer.append("\n");
        return buffer.toString();//StringBuffer 문자열 객체 반환
    }

    @Override
    public void onMapReady  (final GoogleMap googleMap) {
        mMap = googleMap;
        mMap.setOnMarkerClickListener(this);


        //127.0540333   ,   y : 37.74715

        LatLng korean = new LatLng(37.74715, 127.0540333);



        googleMap.moveCamera(CameraUpdateFactory.zoomTo(15));
        googleMap.moveCamera(CameraUpdateFactory.newLatLng(korean));



    }


}
